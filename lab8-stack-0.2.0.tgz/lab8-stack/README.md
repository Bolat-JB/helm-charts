# Lab 8 Stack Deployment Guide

This repository contains the configurations for deploying a multi-tier application (NGINX frontend, Traefik Whoami backend, and Bitnami Redis) using both Kustomize and Helm.

## Prerequisites
* Minikube running locally
* `kubectl` installed and configured
* `helm` (v3+) installed

---

## Part 1: Deploying with Kustomize (Production Overlay)
This method deploys the static manifests into an isolated production namespace with strict NetworkPolicies.

**1. Create the target namespace:**
```bash
kubectl create namespace lab6-prod
```

**2. Apply the Kustomize overlay:**
```bash
kubectl apply -k lab8-kustomize/overlays/prod
```

**3. Verify the deployment:**
```bash
kubectl get all -n lab6-prod
```

---

## Part 2: Deploying with Helm
This method deploys the fully templated application stack, including the Bitnami Redis database dependency.

**1. Add the Bitnami repository:**
```bash
helm repo add bitnami https://charts.bitnami.com/bitnami
helm repo update
```

**2. Download dependencies:**
Navigate to the root `lab8-stack` directory and pull the Redis chart:
```bash
cd lab8-stack
helm dependency update
```

**3. Install the stack:**
```bash
helm install my-upgraded-stack .
```

---

## Part 3: Accessing and Using the Application
The frontend is exposed via a Kubernetes Ingress resource listening for the `myapp.lab.local` hostname.

**1. Get your Minikube IP:**
```bash
minikube ip
```

**2. Map the hostname to your local machine:**
Edit your `/etc/hosts` file (`sudo nano /etc/hosts`) and add the following line, replacing `<MINIKUBE_IP>` with the output from the previous command:
```text
<MINIKUBE_IP> myapp.lab.local
```

**3. Access the web interface:**
Open a web browser and navigate to `http://myapp.lab.local`. You will see the Traefik Whoami backend details, confirming the traffic successfully routed through the NGINX frontend.

---

## Part 4: Updating the Application
If you make changes to the `values.yaml` files or templates in the local Helm chart, apply the changes seamlessly without downtime:

```bash
helm upgrade my-upgraded-stack .
```

To clean up and completely remove the Helm stack:
```bash
helm uninstall my-upgraded-stack
```

---

## Part 5: Deploying from the Public GitHub Pages Registry
The packaged Helm chart is also published as a remote repository via GitHub Pages.

**1. Add the public repository:**
```bash
helm repo add my-lab-repo https://bolat-jb.github.io/helm-charts/
helm repo update
```

**2. Install directly from the remote repository:**
```bash
helm install public-release my-lab-repo/lab8-stack
```