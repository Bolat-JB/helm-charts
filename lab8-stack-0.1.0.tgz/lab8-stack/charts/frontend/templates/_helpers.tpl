{{/* Common labels */}}
{{- define "frontend.labels" -}}
app: {{ .Chart.Name }}
release: {{ .Release.Name }}
{{- end -}}

{{/* Selector labels */}}
{{- define "frontend.selectorLabels" -}}
app: {{ .Chart.Name }}
{{- end -}}