{{/* Common labels */}}
{{- define "backend.labels" -}}
app: {{ .Chart.Name }}
release: {{ .Release.Name }}
{{- end -}}

{{/* Selector labels */}}
{{- define "backend.selectorLabels" -}}
app: {{ .Chart.Name }}
{{- end -}}